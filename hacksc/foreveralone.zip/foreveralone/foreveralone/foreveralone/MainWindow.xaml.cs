﻿using System;
using System.IO;
using System.Configuration;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Kinect;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Blob;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp;
using FireSharp.Response;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Collections.Generic;

namespace foreveralone
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private KinectSensor kinect = null;
        private ColorFrameReader colorFrameReader = null;
        private WriteableBitmap colorBitmap = null;
        private BitmapSource bitmap = null;
        private string result = "";
        private BitmapEncoder encoder = null;
        private CloudStorageAccount account = null;
        private CloudBlobClient blob = null;
        private IFirebaseConfig config = null;
        private IFirebaseClient client = null;
        private string name = ".jpg";
        private string finalName = "";
        private int number;
        BackgroundRemovalTool _backgroundRemovalTool;
        MultiSourceFrameReader reader;
        IList<Body> _bodies;
        private ulong playerID = 0;
        Boolean go = true;

        public MainWindow()
        {
            this.kinect = KinectSensor.GetDefault();
            //this.colorFrameReader = this.kinect.ColorFrameSource.OpenReader();
            //this.colorFrameReader.FrameArrived += ColorframeReader_FrameArrived;

            
            

            FrameDescription colorFrameDescription = this.kinect.ColorFrameSource.CreateFrameDescription(ColorImageFormat.Bgra);
            this.colorBitmap = new WriteableBitmap(colorFrameDescription.Width, colorFrameDescription.Height, 96.0, 96.0, PixelFormats.Bgr32, null);

            if (this.kinect != null)
            {
                this.kinect.Open();
                _backgroundRemovalTool = new BackgroundRemovalTool(kinect.CoordinateMapper);
                reader = kinect.OpenMultiSourceFrameReader(FrameSourceTypes.Color | FrameSourceTypes.Depth | FrameSourceTypes.BodyIndex | FrameSourceTypes.Body);
                reader.MultiSourceFrameArrived += Reader_MultiSourceFrameArrived;

            }

            account = CloudStorageAccount.Parse(ConfigurationManager.AppSettings["StorageConnectionString"]);
            
            blob = account.CreateCloudBlobClient();

            config = new FirebaseConfig
            {
                AuthSecret = "5mEJmENtkosiLf6Dd37yjc4RKXxONSsRuiNWKRJV",
                BasePath = "https://foreveralone.firebaseio.com/"
            };

            client = new FirebaseClient(config);

            InitializeComponent();
        }

        private void Reader_MultiSourceFrameArrived(object sender, MultiSourceFrameArrivedEventArgs e)
        {
            var reference = e.FrameReference.AcquireFrame();

            using (var colorFrame = reference.ColorFrameReference.AcquireFrame())
            using (var depthFrame = reference.DepthFrameReference.AcquireFrame())
            using (var bodyIndexFrame = reference.BodyIndexFrameReference.AcquireFrame())
            {
                if (colorFrame != null && depthFrame != null && bodyIndexFrame != null)
                //if (colorFrame != null )
                {
                    //camera.Source = colorFrame.ToBitmap();
                    //bitmap = colorFrame.ToBitmap1();
                    bitmap = _backgroundRemovalTool.GreenScreen(colorFrame, depthFrame, bodyIndexFrame);
                    camera.Source = bitmap;

                    

                }
            }

            using (var bodyFrame = reference.BodyFrameReference.AcquireFrame())
            {
                if (bodyFrame != null)
                {
                    _bodies = new Body[bodyFrame.BodyFrameSource.BodyCount];

                    bodyFrame.GetAndRefreshBodyData(_bodies);

                    for (int i = 0; i < _bodies.Count; i++)
                    {
                        var body = _bodies[i];

                        if (body != null && body.TrackingId != 0)
                        {
                            if (playerID == 0)
                            {
                                playerID = body.TrackingId;
                            }

                            if (playerID == body.TrackingId && go == true)
                            {
                                Thread.Sleep(3000);
                                go = false;
                                work();
                                
                            }
                        }
                        

                        
                    }
                }
            }
        }

        public async void sendRequest()
        {
            SetResponse response = await client.SetAsync("screenshot", "True");
        }

        public async void sendNumber()
        {
            SetResponse response = await client.SetAsync("count", number.ToString());
        }
        

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            if (this.colorFrameReader != null)
            {
                // ColorFrameReder is IDisposable
                this.colorFrameReader.Dispose();
                this.colorFrameReader = null;
            }

            if (this.kinect != null)
            {
                this.kinect.Close();
                this.kinect = null;
            }
        }

        private async void work()
        {
            string folder;

            if (bitmap != null)
            {
                encoder = new JpegBitmapEncoder();

                encoder.Frames.Add(BitmapFrame.Create(this.bitmap));

                folder = @"C:\Users\SmrtAsian95\Desktop\targets";
                result = Path.Combine(folder, "ben.jpg");
            }

            try
            {
                // FileStream is IDisposable
                using (FileStream fs = new FileStream(result, FileMode.Create))
                {
                    encoder.Save(fs);
                }

                Console.WriteLine("file saved!");
            }
            catch (IOException)
            {
                Console.WriteLine("file failed!");
            }

            CloudBlobContainer container = blob.GetContainerReference("picture");
            container.CreateIfNotExists();

            container.SetPermissions(
                new BlobContainerPermissions
                {
                    PublicAccess =
                BlobContainerPublicAccessType.Blob
                });



            //getFileName();

            FirebaseResponse response1 = await client.GetAsync("count");

            string count = response1.ResultAs<string>();

            Console.WriteLine("Ben: " + count);

            number = Int32.Parse(count) + 1;

            finalName = count + name;

            CloudBlockBlob blockBlob = container.GetBlockBlobReference(finalName);


            using (var fileStream = System.IO.File.OpenRead(result))
            {

                blockBlob.UploadFromStream(fileStream);
                Console.WriteLine("Successful!");
            }

            Thread.Sleep(5000);

            sendRequest();


            sendNumber();

            /*
            using (var fileStream = System.IO.File.OpenRead(result))
            {
                Console.WriteLine(result);
                blockBlob.UploadFromStream(fileStream);
                Console.WriteLine("Successful!");
            }*/

        }

        private async void button_Click(object sender, RoutedEventArgs e)
        {
            string folder;

            if (bitmap != null)
            {
                encoder = new JpegBitmapEncoder();

                encoder.Frames.Add(BitmapFrame.Create(this.bitmap));

                folder = @"C:\Users\SmrtAsian95\Desktop\targets";
                result = Path.Combine(folder, "ben.jpg");
            }
            
            try
            {
                // FileStream is IDisposable
                using (FileStream fs = new FileStream(result, FileMode.Create))
                {
                    encoder.Save(fs);
                }

                Console.WriteLine("file saved!");
            }
            catch (IOException)
            {
                Console.WriteLine("file failed!");
            }

            CloudBlobContainer container = blob.GetContainerReference("picture");
            container.CreateIfNotExists();

            container.SetPermissions(
                new BlobContainerPermissions
                {
                    PublicAccess =
                BlobContainerPublicAccessType.Blob
            });



            //getFileName();

            FirebaseResponse response1 = await client.GetAsync("count");

            string count = response1.ResultAs<string>();

            Console.WriteLine("Ben: " + count);

            number = Int32.Parse(count) + 1;

            finalName =  count + name;

            CloudBlockBlob blockBlob = container.GetBlockBlobReference(finalName);
    
            
            using (var fileStream = System.IO.File.OpenRead(result))
            {
                
                blockBlob.UploadFromStream(fileStream);
                Console.WriteLine("Successful!");
            }

            Thread.Sleep(5000);

            sendRequest();


            sendNumber();

            /*
            using (var fileStream = System.IO.File.OpenRead(result))
            {
                Console.WriteLine(result);
                blockBlob.UploadFromStream(fileStream);
                Console.WriteLine("Successful!");
            }*/


        }
    }
}
